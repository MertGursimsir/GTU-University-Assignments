#include <stdio.h>
#include <string.h>
#include "ecrypt-sync.h"


void printData(u8 *key, u8 *initializationVector, u8 *inputKS, u8 *plaintext, u8 *ciphertext, const int mode) {
	u32 i;

	printf("\nPlaintext -> ");	
	
	for (i = 0; i < 16; ++i)
		printf("%02x",plaintext[i]);
	
	printf("\nCiphertext -> ");	
	
	for (i = 0; i < 16; ++i) 
		printf("%02x",ciphertext[i]);	

	printf("\nKey -> ");

	for (i = 0; i < 16; ++i)
		printf("%02x",key[i]);

	printf("\nKeystream -> ");

	for (i = 0; i < 16; ++i)
		printf("%02x",inputKS[i]);

	if (mode == 2){
		printf("\nInitialization vector -> ");
		for (i = 0; i < 12; ++i)
			printf("%02x",initializationVector[i]);
	}	
	
	
}

void tests() {
	ECRYPT_ctx ecryptValue;

	u8 firstInitializationVector[12] = {0x22,0xf5,0x4f,0x00,0x0f,0xb9,0x00,0xa6,0xab,0xf4,0x00,0x00},
	   inputKS[16],
	   plaintext[16] = {0x07,0x27,0x45,0xab,0xc5,0x4a,0xcc,0xa5,0x42,0x34,0x47,0x17,0xaf,0xec,0xd4,0x44},
	   ciphertext[16];

	u8 keyValue[16] = {0x44,0x12,0xa5,0x50,0x32,0xcb,0xab,0x43,0xaf,0x56,0xab,0x78,0x4f,0x5c,0xe4,0xc9},
	   secondInitializationVector[12] = {0x12,0xf2,0x45,0x00,0xff,0xbb,0x42,0xaf,0x94,0x11,0x00,0x00};
	
	u32 length = 16;

	ECRYPT_keysetup(&ecryptValue, keyValue, 128, 96);
	ECRYPT_ivsetup(&ecryptValue, firstInitializationVector);
	ECRYPT_keystream_bytes(&ecryptValue, inputKS, 16);
	ECRYPT_encrypt_bytes(&ecryptValue, ciphertext, plaintext, length);

	int mode = 0;

	printf("\nENCRYPTION\n");
	printf("--------------");	
	printData(keyValue, firstInitializationVector, inputKS, plaintext, ciphertext, mode);

	printf("\n\nDECRYPTION\n----------");
	ECRYPT_decrypt_bytes(&ecryptValue, plaintext, ciphertext, length);
	printf("\nPlaintext:  ");	
	for (int i=0;i<16;++i)
		printf("%02x", plaintext[i]);

	printf("\n");


	////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////


	ECRYPT_keysetup(&ecryptValue, keyValue, 128, 96);
	ECRYPT_ivsetup(&ecryptValue, secondInitializationVector);
	ECRYPT_keystream_bytes(&ecryptValue, inputKS, 16);
	ECRYPT_encrypt_bytes(&ecryptValue, ciphertext, plaintext, length);
	

	mode = 1;

	printf("\n\nOFB ENCRYPTION");
	printf("\n------------------");
	printData(keyValue, firstInitializationVector, inputKS, plaintext, ciphertext, mode);

	printf("\n\nDECRYPTION\n----------");
	ECRYPT_decrypt_bytes(&ecryptValue, plaintext, ciphertext, length);
	printf("\nPlaintext:  ");	
	for (int i=0;i<16;++i) printf("%02x", plaintext[i]);

	printf("\n");

	////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////

	mode = 2;

	printf("\n\nCBC ENCRYPTION");
	printf("\n------------------");
	ECRYPT_ivsetup(&ecryptValue, firstInitializationVector);
	ECRYPT_keysetup(&ecryptValue, keyValue, 128, 96);
	
	ECRYPT_keystream_bytes(&ecryptValue, inputKS, 16);
	ECRYPT_encrypt_bytes(&ecryptValue, ciphertext, plaintext, length);
	printData(keyValue, firstInitializationVector, inputKS, plaintext, ciphertext, mode);

	printf("\n\nDECRYPTION\n----------");
	ECRYPT_decrypt_bytes(&ecryptValue, plaintext, ciphertext, length );
	printf("\nPlaintext:  ");	
	for (int i=0;i<16;++i) printf("%02x", plaintext[i]);
		printf("\n");
}

int main() {
	printf("**************************************\n");
	printf("LIGHTWEIGHT ALGORITHMS GRAIN128 - AEAD\n");
	printf("**************************************\n");

	tests();

	printf("\nGOOD-BYE!\n");
	printf("    ~Mert Gursimsir\n\n");

	return 0;
}