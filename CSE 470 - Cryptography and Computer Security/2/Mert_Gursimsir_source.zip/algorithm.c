/**
 * MERT GURSIMSIR
 * 1901042646
 */

#include "ecrypt-sync.h"

u8 keyStreamOfGrain(ECRYPT_ctx* inputValue);

//ENCRYPTION
void ECRYPT_encrypt_bytes(ECRYPT_ctx* inputValue, const u8* msg, u8* ciphertext, u32 length)
{
	u32 i,j;
	u8 k=0;
	for (i = 0; i < length; ++i) {
		k=0;
		for (j = 0; j < 8; ++j) {
			k|=(keyStreamOfGrain(inputValue)<<j);
		}
		ciphertext[i]=msg[i]^k;
	}
}

//DECRYPTION
void ECRYPT_decrypt_bytes(ECRYPT_ctx* inputValue, const u8* ciphertext, u8* plaintext, u32 length)
{
	u32 i, j;
	u8 k = 0;
	for (i = 0; i < length; ++i) {
		k=0;
		for (j = 0; j < 8; ++j) {
			k|=(keyStreamOfGrain(inputValue)<<j);
		}
		plaintext[i]=ciphertext[i]^k;
	}
}

/******************************************************************************************************************************/
/******************************************************************************************************************************/
/******************************************************************************************************************************/

//WITH THIS FUNCTION, I LOAD THE KEY AND PERFORM INITIAL CLOCKINGS
//I AM USING NFSR AND LFSR THAT ARE MENTIONED AT THE REPORT
void ECRYPT_ivsetup(ECRYPT_ctx* inputValue, const u8* initializationVector)
{
	u32 i,j;
	u8 out;
	
	for (i = 0; i < (inputValue->ivsize)/8; ++i) {
		for (j = 0; j < 8; ++j) {
			inputValue->NFSR[i*8+j] = ((inputValue->p_key[i]>>j)&1);  
			inputValue->LFSR[i*8+j] = ((initializationVector[i]>>j)&1);
		}
	}

	for (i=(inputValue->ivsize)/8; i<(inputValue->keysize)/8; ++i) {
		for (j = 0; j<8; ++j) {
			inputValue->NFSR[i*8+j] = ((inputValue->p_key[i]>>j)&1);
			inputValue->LFSR[i*8+j] = 1;
		}
	}
	
	for (i = 0; i < 256; ++i) {
		out=keyStreamOfGrain(inputValue);
		inputValue->LFSR[127]^=out;
		inputValue->NFSR[127]^=out;             
	}
}

void ECRYPT_keysetup(ECRYPT_ctx* inputValue, const u8* p_key, u32 keysize,u32 ivsize)			
{
	inputValue->p_key=p_key;
	inputValue->keysize=keysize;
	inputValue->ivsize=ivsize;
}

/******************************************************************************************************************************/
/******************************************************************************************************************************/
/******************************************************************************************************************************/


//KEYSTREAM BYTES ARE GENERATING HERE
void ECRYPT_keystream_bytes(ECRYPT_ctx* inputValue, u8* keystream, u32 length)
{
	u32 i, j;
	for (i = 0; i < length; ++i) {
		keystream[i] = 0;
		for (j = 0; j < 8; ++j) {
			keystream[i]|=(keyStreamOfGrain(inputValue)<<j);
		}
	}
}

//GRAIN KEYSTREAM FUNCTION RETURNS U8
/***********************************/
u8 keyStreamOfGrain(ECRYPT_ctx* inputValue) {
	u8 iterator, OtherNBit, LeftBitValue, toBeReturned;
	
	toBeReturned = inputValue->NFSR[2]^inputValue->NFSR[15]^inputValue->NFSR[36]^inputValue->NFSR[45]^inputValue->NFSR[64]^inputValue->NFSR[73]^inputValue->NFSR[89]^inputValue->LFSR[93]^(inputValue->NFSR[12]&inputValue->LFSR[8])^(inputValue->LFSR[13]&inputValue->LFSR[20])^(inputValue->NFSR[95]&inputValue->LFSR[42])^(inputValue->LFSR[60]&inputValue->LFSR[79])^(inputValue->NFSR[12]&inputValue->NFSR[95]&inputValue->LFSR[95]);
	OtherNBit   = inputValue->LFSR[0]^inputValue->NFSR[0]^inputValue->NFSR[26]^inputValue->NFSR[56]^inputValue->NFSR[91]^inputValue->NFSR[96]^(inputValue->NFSR[3]&inputValue->NFSR[67])^(inputValue->NFSR[11]&inputValue->NFSR[13])^(inputValue->NFSR[17]&inputValue->NFSR[18])^(inputValue->NFSR[27]&inputValue->NFSR[59])^(inputValue->NFSR[40]&inputValue->NFSR[48])^(inputValue->NFSR[61]&inputValue->NFSR[65])^(inputValue->NFSR[68]&inputValue->NFSR[84]);
	LeftBitValue   = inputValue->LFSR[0]^inputValue->LFSR[7]^inputValue->LFSR[38]^inputValue->LFSR[70]^inputValue->LFSR[81]^inputValue->LFSR[96];
	
	for (iterator = 1; iterator < (inputValue->keysize); ++iterator) {
		inputValue->NFSR[iterator-1]=inputValue->NFSR[iterator];
		inputValue->LFSR[iterator-1]=inputValue->LFSR[iterator];
	}

	inputValue->NFSR[(inputValue->keysize)-1]=OtherNBit;
	inputValue->LFSR[(inputValue->keysize)-1]=LeftBitValue;
	
	return toBeReturned;
}
